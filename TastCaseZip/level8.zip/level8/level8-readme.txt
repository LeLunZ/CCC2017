The input files for this level represent the following geographic areas:
1 - Austria
2 - Africa
3 - North America
4 - Europe
